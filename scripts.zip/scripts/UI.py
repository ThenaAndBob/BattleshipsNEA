from abc import abstractclassmethod
from Game import Game
import os
import random
import pygame as pg
from art import *
from network import Network
from PIL import Image
import time

class UI():
    def __init__(self):
        self._username = "" 
        with open(f"options.txt", "r") as f:
            data = f.readline()
            data = data.split(",")
        data = list(map(int, data))
        Game.changeBoardDimensions(data[0], data[1])
        for index, number in enumerate(data[2:8]):
            Game.changeShips(index, number)
        for index, number in enumerate(data[8:13]):
            Game.changeSpecials(index, number)
        Game.changeNumPlayers(data[13])
        Game.updatePlayers()

        #########################################################################
        #
        # CATEGORY A SKILL: Composition
        # Defining a self._network variable which is a Network object. UI has a Network.
        #
        #########################################################################       
        try:
            self._network = Network()
            pass
        except:
            print("Could not connect to server")

    @abstractclassmethod
    def __run():
        raise NotImplementedError

    @abstractclassmethod
    def __local():
        raise NotImplementedError

    @abstractclassmethod
    def __networkGame():
        raise NotImplementedError

    @abstractclassmethod
    def __help():
        raise NotImplementedError

    @abstractclassmethod
    def __load():
        raise NotImplementedError

    @abstractclassmethod
    def __save():
        raise NotImplementedError

    @abstractclassmethod
    def __mainMenu():
        raise NotImplementedError

    @abstractclassmethod
    def __playMenu():
        raise NotImplementedError


    @abstractclassmethod
    def __stats():
        raise NotImplementedError

    @abstractclassmethod
    def __options():
        raise NotImplementedError


        
    #########################################################################
    #
    # CATEGORY A SKILL: HASHING
    # Using a hashing algorithm to securely transfer user passwords.
    #
    #########################################################################
    def hash(self, toHash):
        length = 100
        if len(toHash) >= length:
            return None
        else:
            while len(toHash)*2 <= 100:
                toHash += toHash
            toHash += toHash[:100-len(toHash)]
            print(len(toHash))

        prev = ord(toHash[0]) ^ ord(toHash[-1])
        new = chr(prev)
        for _ in range(1000):
            for ch in toHash[1:]:
                ch = ((ord(ch)^prev)%26)+65
                new += chr(((ch^prev) % 26) + 65)
                prev = (ch % 26) + 65
            toHash = new
            new = chr(prev)
        print("DEBUG -- hash complete")
        return toHash

    def compareStats(self, s1, s2): # wins,losses,hits,misses,highestHP,leastAttack INTEGER LISTS
        stats = [s1,s2]
        winrates = []
        hitrates = []
        for statList in stats:
            if statList[0] == statList[1] == 0:
                winrates.append(0)
            else:
                winrates.append(statList[0]/(statList[0]+statList[1]))

            if statList[2] == statList[3] == 0:
                hitrates.append(0)
            else:
                hitrates.append(statList[2]/(statList[2]+statList[3]))

        if abs(winrates[0]-winrates[1]) > 0.1:
            if winrates[0] < winrates[1]:
                return 0
            else:
                return 1
        if abs(hitrates[0]-hitrates[1]) > 0.1:
            if hitrates[0] < hitrates[1]:
                return 0
            else:
                return 1
        return -1


    #########################################################################
    #
    # CATEGORY B SKILL: Text files and reading/writing from text files
    # Reading a text file and then updating its contents based on a dictionary.
    #
    #########################################################################
    #########################################################################
    #
    # CATEGORY B SKILL: Dictionaries
    # Using a dictionary to know which options to change, and what they should
    # be changed to.
    #
    #########################################################################
    def updateOptions(self, changed):
        Game.updatePlayers()
        with open("options.txt", "r") as f:
            data = f.readline().split(",")
        for index, newValue in changed.items():
            data[index] = str(newValue)

        with open("options.txt", "w") as f:
            f.writelines(",".join(data))

#########################################################################
#
# CATEGORY A SKILL: Inheritance
# The GUI inherits from the base UI class.
#
#########################################################################
class GUI(UI):
    def __init__(self):
        super().__init__()
        self._scale = 20
        self._width = 48*self._scale
        self._height = 27*self._scale
        self._finalImagePath = f"FinalImages\\Scale{self._scale}\\"
        self._fillColour = (0,168,243)

    def run(self):
        self.__mainMenu()

    def __stats(self): 
        if self._username != "":
            stats = self._network.send(f"getStats {self._username}") # Returns comma seperated string
        else:
            return
        letters = []
        for character in stats:
            letters.append(pg.image.load(f"{self._finalImagePath}{character}.png"))        
        
        alphabet = []
        alphabet = [pg.image.load(f"{self._finalImagePath}{ch}.png") for ch in "abcdefghijklmnopqrstuvwxyz"]
        titles = ["wins", "losses", "hits", "misses", "maxhp", "attacks"]

        pg.init()
        screen = pg.display.set_mode((self._width, self._height))
        runningStats = True
        camera = 0
        clock = pg.time.Clock()

        while runningStats:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                elif event.type == pg.KEYDOWN:
                    if event.key == pg.K_ESCAPE:
                        runningStats = False
                elif event.type == pg.MOUSEWHEEL:
                    camera += event.y*30
            clock.tick(60)
            

            screen.fill(self._fillColour)
            xposition = 0
            letterSize = 3
            yposition = self._scale
            for ch in titles[0]:
                screen.blit(alphabet[ord(ch)-97], (xposition, yposition + camera))
                if ch == "m" or ch == "w":
                    letterSize = 6
                elif ch == "q":
                    letterSize = 5
                elif ch == "i":
                    letterSize = 2
                else:
                    letterSize = 4
                xposition += self._scale * letterSize
            xposition += self._scale * letterSize
            i = 1
            for index, letter in enumerate(letters):
                if stats[index] == ",":
                    yposition += 6*self._scale
                    xposition = 0
                    for ch in titles[i]:
                        screen.blit(alphabet[ord(ch)-97], (xposition, yposition + camera))
                        if ch == "m" or ch == "w":
                            letterSize = 6
                        elif ch == "q":
                            letterSize = 5
                        elif ch == "i":
                            letterSize = 2
                        else:
                            letterSize = 4
                        xposition += self._scale * letterSize
                    xposition += self._scale * letterSize
                    i += 1
                else:
                    screen.blit(letter, (xposition, yposition+camera))
                    xposition += self._scale*3
            pg.display.update()

    def __mainMenu(self):
        # Initialise
        pg.init()
        screen = pg.display.set_mode((self._width, self._height))
        runningMenu = True

        # Buttons
        rects = []
        buttonImages = [pg.image.load(f"{self._finalImagePath}LoginButton.png"), pg.image.load(f"{self._finalImagePath}SignUpButton.png"), pg.image.load(f"{self._finalImagePath}GuestButton.png"), pg.image.load(f"{self._finalImagePath}QuitButton.png")] 
        backgroundImage = pg.image.load(f"{self._finalImagePath}MainMenu.png") 
        for image in buttonImages:
            rects.append(image.get_rect())
        # Position buttons correctly.
        rects[0].update(int(round((5/96)*self._width)), int(round((19/54)*self._height)), rects[0].width, rects[0].height)
        rects[1].update(int(round((5/96)*self._width)), int(round((38/54)*self._height)), rects[1].width, rects[1].height)
        rects[2].update(int(round((53/96)*self._width)), int(round((19/54)*self._height)), rects[2].width, rects[2].height)
        rects[3].update(int(round((53/96)*self._width)), int(round((38/54)*self._height)), rects[3].width, rects[3].height)
        rects.append(pg.Rect(41*self._scale, 22*self._scale, 6*self._scale, 4*self._scale))
        

        while runningMenu:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    runningMenu = False
                elif event.type == pg.KEYDOWN:
                    if event.key == pg.K_ESCAPE:
                        runningMenu = False
                elif event.type == pg.MOUSEBUTTONDOWN: # Check if player pressed mouse
                    if event.button == 1: # Check if player pressed left mouse button
                        point = pg.mouse.get_pos() 
                        for i, rect in enumerate(rects):
                            if rect.collidepoint(point):
                                if i == 0:
                                    self.__authenticate("login")
                                elif i == 1:
                                    self.__authenticate("signup")
                                elif i == 2:
                                    self.__playMenu()
                                elif i == 3:
                                    runningMenu = False
                                elif i == 4:
                                    self.__stats()

            screen.blit(backgroundImage, (0,0))
            for image, rect in zip(buttonImages, rects):
                screen.blit(image, rect)

            pg.display.update()

    def __playMenu(self):
        # Initialise
        pg.init()
        screen = pg.display.set_mode((self._width, self._height))
        runningPlayMenu = True

        # Buttons
        rects = [None for _ in range(7)]
        backgroundImagePlayMenu = pg.image.load(f"{self._finalImagePath}playMenu.png") 
        rects[0] = pg.Rect(3*self._scale, 11*self._scale, 19*self._scale, 5*self._scale)
        rects[1] = pg.Rect(24*self._scale,11*self._scale,21*self._scale,5*self._scale)
        rects[2] = pg.Rect(3*self._scale, 18*self._scale, 5*self._scale, 5*self._scale)
        rects[3] = pg.Rect(37*self._scale,20*self._scale,3*self._scale,5*self._scale)
        rects[4] = pg.Rect(31*self._scale,20*self._scale,5*self._scale,5*self._scale)
        rects[5] = pg.Rect(12*self._scale,18*self._scale,15*self._scale,5*self._scale)
        rects[6] = pg.Rect(41*self._scale,20*self._scale,5*self._scale,5*self._scale)

        while runningPlayMenu:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    runningPlayMenu = False
                elif event.type == pg.KEYDOWN:
                    if event.key == pg.K_ESCAPE:
                        runningPlayMenu = False
                elif event.type == pg.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        # Check which menu button it collided with and call that function.
                        point = pg.mouse.get_pos()
                        for i, rect in enumerate(rects):
                            if rect.collidepoint(point):
                                if i == 0:
                                    print("Starting regular game")
                                    self.__local(False, 0)
                                elif i == 1:
                                    print("Starting online game")
                                    self.__local(True, 0)
                                elif i == 2:
                                    aiDifficulty = self.__getUserInput("aidifficulty")
                                    try:
                                        aiDifficulty = int(aiDifficulty)
                                    except ValueError:
                                        break
                                    self.__local(False, aiDifficulty)
                                elif i == 3:
                                    self.__help()
                                elif i == 4:
                                    self.__options()
                                elif i == 5:
                                    self.__load()
                                else:
                                    runningPlayMenu = False
                                    pg.quit()
            screen.blit(backgroundImagePlayMenu, (0,0))
            pg.display.update()

    def __local(self, network, ai, game=None): # Network is a boolean
        # Initialise
        pg.init()
        Game.updatePlayers()
        Game.changeAI(ai)
        screen = pg.display.set_mode((self._width, self._height))
        runningLocal = True
        currentPlayer = 0
        shipHP = Game.getShips()
        numships = Game.getNumShips()
        #########################################################################
        #
        # CATEGORY A SKILL: Composition
        # Storing a Game object as a characteristic of the GUI class
        #
        #########################################################################
        if game is None:
            self._game = Game()
            numPlayers = Game.getNumPlayers()
        else:
            self._game = game[0]
            numPlayers = 2

        # Grid
        WidthInSquares = Game.getWidth() # Dimensions of the grid in squares.
        HeightInSquares = Game.getHeight()
        squareSize = round(self._scale*2.5) 

        if network:
            enemyName = self.__getUserInput("EnemyName")
            playerNum, gameID = self._network.send(f"startGame {self._username} {enemyName}").split(" ")
            playerNum = int(playerNum[1]) - 1
            numPlayers = 1
            try:
                myStats = list(map(int, self._network.send(f"getStats {self._username}").split(","))) # wins,losses,hits,misses,highestHP,leastAttacks
                enemyStats = list(map(int, self._network.send(f"getStats {enemyName}").split(",")))
                needsHelp = self.compareStats(myStats, enemyStats)
                print(myStats, enemyStats)
            except:
                needsHelp = -1
            if needsHelp != -1:
                if needsHelp == 0 and self.__getUserInput(f"Help,Y,N").lower() == "y":
                    self.__options()
                    pg.quit()
                    self.__mainMenu()
                    return
                elif needsHelp == 0:
                    playerNum, gameID = self._network.send(f"startGame {self._username} {enemyName}").split(" ")
                    playerNum = int(playerNum[1]) - 1          
                elif needsHelp == 1:
                    self._network.send(f"deletegame {gameID}")
                    playerNum, gameID = self._network.send(f"startGame {self._username} {enemyName}").split(" ")
                    playerNum = int(playerNum[1]) - 1
                    
            
        # Ships
        rects = []
        shipAttach = [0 for _ in range(numships)]
        shipImages = []
        for ship in shipHP:
            shipImages.append(pg.image.load(f"{self._finalImagePath}HP{ship}Ship.png"))
        shipRotation = [0 for _ in range(numships)]
        for image in shipImages:
            rects.append(image.get_rect())

        # Buttons
        buttonImages = [pg.image.load(f"{self._finalImagePath}HP2Ship.png")]
        buttonRects = []
        for x in range(len(buttonImages)):
            buttonRects.append(buttonImages[x].get_rect())
        buttonRects[0].update(0, self._height-(2*buttonRects[0].height), buttonRects[0].width, buttonRects[0].height)


        # Edges of the grid
        left = (self._width - WidthInSquares*squareSize)//2   # Edges are five squares from the centre.
        right = (self._width + WidthInSquares*squareSize)//2
        top = (self._height - HeightInSquares*squareSize)//2
        bot = (self._height + HeightInSquares*squareSize)//2
        squares = []

        # Storing grid object in squares 
        for x in range(left, right, squareSize):
            for y in range(top, bot, squareSize):
                squares.append(pg.Rect(x, y, squareSize, squareSize))
        
        playerNumberImage = [pg.image.load(f"{self._finalImagePath}P.png"), pg.image.load(f"{self._finalImagePath}{currentPlayer+1}.png")]

        # Loop for placing ships
        if game is None: # We would skip this part if the game was loaded.
            while runningLocal:
                for event in pg.event.get():
                    if event.type == pg.QUIT:
                        runningLocal = False
                        if network:
                            self._network.send(f"deletegame {gameID}")
                        pg.quit()
                    elif event.type == pg.KEYDOWN:
                        if event.key == pg.K_r: 
                            for x in range(len(shipAttach)):
                                if shipAttach[x] == 1:
                                    if shipRotation[x]:
                                        shipRotation[x] = 0
                                    else:
                                        shipRotation[x] = 1
                                    shipImages[x] = pg.transform.rotate(shipImages[x], -90)
                                    rects[x] = shipImages[x].get_rect()
                                    break
                    elif event.type == pg.MOUSEBUTTONDOWN:
                        if event.button == 1 and 1 not in shipAttach:
                            point = pg.mouse.get_pos()
                            changePlayer = True
                            if buttonRects[0].collidepoint(point) and 0 not in shipAttach and 1 not in shipAttach:  # buttonRects[0] is the done button
                                # place down all ships and swap turns (and move ships back) or move on to actual game.
                                for x in range(len(rects)):
                                    shipLocation = [(rects[x].left - left)//squareSize, (rects[x].top-top)//squareSize,shipRotation[x], shipHP[x]]
                                    shipResult = self._game.addShip(currentPlayer, shipLocation)
                                    print(shipResult)
                                    if shipRotation[x]:
                                        shipImages[x] = pg.transform.rotate(shipImages[x], -90)
                                        rects[x] = shipImages[x].get_rect()
                                        shipRotation[x] = 0
                                    rects[x].update(0, 0, rects[x].width, rects[x].height) 
                                    if shipResult == -1:
                                        changePlayer = False
                                
                                if changePlayer:
                                    if currentPlayer == 0:
                                        if ai != 0:
                                            x = 0
                                            while x < len(shipHP):
                                                print(x, shipHP)
                                                if self._game.addShip(1,self._game.getAIShip(x)) == 1:
                                                    x += 1
                                            runningLocal = False
                                    if currentPlayer == numPlayers-1:
                                        runningLocal = False
                                    currentPlayer += 1
                                    playerNumberImage[1] = pg.image.load(f"{self._finalImagePath}{currentPlayer+1}.png")
                                else:
                                    self._game.clearBoard(currentPlayer)

                            for x in range(len(rects)):
                                if rects[x].collidepoint(point): # Checks if the mouse is on one of the ships.
                                    # Mouse attaches to ship and starts moving it around.
                                    shipAttach[x] = 1
                                    break  # Break cause otherwise you can pick up multiple ships at once.
                    elif event.type == pg.MOUSEBUTTONUP:
                        if event.button == 1 and 1 in shipAttach:
                            point = pg.mouse.get_pos()
                            for x in range(len(shipAttach)):
                                if shipAttach[x] == 1: # If the ship is currently being held, place it down.
                                    shipAttach[x] = 2

                                    if shipRotation[x]:
                                        rects[x].update(squareSize * round((point[0] - (left % squareSize) - squareSize/2)/squareSize) + (left % squareSize), squareSize * round((point[1] - (top % squareSize) - shipHP[x]*squareSize/2)/squareSize) + (top % squareSize), rects[x].width, rects[x].height)
                                    else:
                                        rects[x].update(squareSize * round((point[0] - (left % squareSize) -  shipHP[x]*squareSize/2)/squareSize) + (left % squareSize), squareSize * round((point[1] - (top % squareSize) - squareSize/2)/squareSize) + (top % squareSize), rects[x].width, rects[x].height)
                                    
                                    break

                screen.fill(self._fillColour)
                for x in range(len(shipAttach)):  # Makes a ship follow the mouse around once it has been clicked.
                    if shipAttach[x] == 1:
                        rects[x].update(pg.mouse.get_pos()[0] - rects[x].width/2, pg.mouse.get_pos()[1] - rects[x].height/2, rects[x].width, rects[x].height)

                for square in squares:
                    pg.draw.rect(screen, (255,255,255), square, 1)

                for x in range (len(rects)):
                    screen.blit(shipImages[x], rects[x])

                for x in range(len(buttonImages)):
                    screen.blit(buttonImages[x], buttonRects[x])

                P, pn = playerNumberImage
                screen.blit(P, (round(screen.get_width()-(6*self._scale)), 0))
                screen.blit(pn, (round(screen.get_width()-(3*self._scale)), 0))
                pg.display.update()

            if network:
                board = self._game.getBoard(0)
                grid = ""
                for y, row in enumerate(board):
                    for x, value in enumerate(row):
                        if value == 1:
                            grid += f"{x},{y}|"

                grid = grid[:-1]
                self._network.send(f"updateGrids {grid} {gameID} {playerNum}")
                enemyGrid = self._network.send(f"getGrid {gameID} {(playerNum+1)%2}").split("|")
                for coordinate in enemyGrid:
                    x,y = coordinate.split(",")
                    self._game.addShip(1, f"{x}{y}11")

        #
        #
        #
        # ATTACKING STARTS
        #
        #
        #
        currentPlayer = 0
        playerNumbers = [num for num in range(numPlayers)]
        runningLocal = True
        squareSize = min(self._width//(2*WidthInSquares+3), self._height//HeightInSquares) # Scale it down so that two grids can fit.
        numAttacked = 0
        hits = 0
        misses = 0

        # Edges of the grids
        left = 3*self._scale
        r1 = left + WidthInSquares*squareSize
        right = r1 + squareSize + WidthInSquares*squareSize
        top = int(squareSize)
        bot = int(top + HeightInSquares*squareSize)
        squares = []
        enemySquares = []
        enemySecretBoard = []
        # Storing grid object in squares 
        for y in range(top, bot, squareSize):
            for x in range(left, r1, squareSize):
                squares.append(pg.Rect(x, y, squareSize, squareSize))

        for y in range(top, bot, squareSize):
            for x in range(r1+squareSize, right, squareSize):
                enemySquares.append(pg.Rect(x,y,squareSize,squareSize))

        attackTypePaths = [f"{self._finalImagePath}N.png", f"{self._finalImagePath}B.png", f"{self._finalImagePath}R.png"]
        attackType = 0
        attackTypeImage = pg.image.load(attackTypePaths[attackType])
        attackTypeRect = attackTypeImage.get_rect()
        attackTypeRect.update(0,0,0,0)
        #numbers
        numberImages = [pg.image.load(f"{self._finalImagePath}{num}.png") for num in range(10)]

        # Game loop   
        postHit = False         
        while runningLocal:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    runningLocal = False
                    if network:
                        self._network.send(f"deletegame {gameID}")
                    pg.quit()
                elif event.type == pg.KEYDOWN:
                    if postHit:
                        postHit = False
                        if isinstance(result, list) and len(result) == 1:
                            runningLocal = False 
                    elif event.key == pg.K_s:
                        if len(self._username):
                            self.__save() 
                            runningLocal = False
                    elif event.key == pg.K_c:
                        # Change the attacktype
                        attackType = (attackType+1)%3
                        attackTypeImage = pg.image.load(attackTypePaths[attackType])
                        attackTypeRect = attackTypeImage.get_rect()
                elif event.type == pg.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        point = pg.mouse.get_pos()
                        if attackTypeRect.collidepoint(point): 
                            # Change the attacktype
                            attackType = (attackType+1)%3
                            attackTypeImage = pg.image.load(attackTypePaths[attackType]) 
                            attackTypeRect = attackTypeImage.get_rect()
                            break
                        for x in range(len(enemySquares)):
                            if enemySquares[x].collidepoint(point): # Checks if the mouse is inside one of the grid squares.
                                # attack that square and swap sides
                                if network:
                                    toAttack = 1
                                else:
                                    toAttack = playerNumbers[(currentPlayer+1+numAttacked) % numPlayers]

                                coords = [squareSize * round((point[0] - ((left + right//2 )% squareSize) - squareSize/2)/squareSize) + ((left + right//2) % squareSize), squareSize * round((point[1] - (top % squareSize) - squareSize/2)/squareSize) + (top % squareSize)]
                                coordinput = [(coords[0] - (left+right//2))//squareSize, (coords[1] - (top))//squareSize]

                                if attackType == 2:
                                    result = self._game.radar(toAttack, playerNumbers[currentPlayer])
                                    if len(result) == 0:
                                        break
                                    postHit = True
                                else:
                                    result = self._game.attack(coordinput[0], coordinput[1], toAttack, attackType, playerNumbers[currentPlayer])
                                if result == 2:
                                    numPlayers -= 1
                                    if numPlayers <= 1:
                                        print(f"Player {playerNumbers[currentPlayer]+1} won!")
                                        result = [playerNumbers[currentPlayer]+1]
                                    else:
                                        print(toAttack+1, "was eliminated.")
                                        playerNumbers.remove(toAttack)
                                elif result == 1:
                                    print("Hit!")
                                    hits += 1
                                    pass
                                elif result == -1:
                                    print("Miss!")
                                    misses += 1
                                    pass
                                if result == -2:
                                    # error or already attacked ship
                                    print("Decrementing numAttacked.")
                                    numAttacked -= 1
                                    postHit = False

                                if network and result != -2:
                                    previousAttack = self._network.send(f"updatePreviousAttack {coordinput[0]} {coordinput[1]} {playerNum} {attackType} {gameID}")
                                    x, y, enemyattackType, pnumignore = map(int, previousAttack.split(" "))
                                    if result == [1]:
                                        postHit = True
                                        break
                                    if enemyattackType != 2:
                                        if self._game.attack(x, y, 0, enemyattackType) == 2:
                                            result = [2]
                                            postHit = True
                                    break # Because we don't want to change the playernumber
    
                                numAttacked += 1

                                if numAttacked >= numPlayers-1:
                                    postHit = True
                                    currentPlayer = (currentPlayer + 1) % numPlayers
                                    numAttacked = 0
                                if currentPlayer == 1 and ai != 0:
                                    airesult = -2
                                    print("outside while")
                                    while airesult == -2:
                                        x,y = self._game.getAIAttack()
                                        print("inside while")
                                        airesult = self._game.attack(x,y,0,0)

                                    if airesult == 2:
                                        print("AI won!")
                                        result = [2]

                                    currentPlayer = (currentPlayer + 1) % numPlayers
                                    numAttacked = 0

                                print(playerNumbers,currentPlayer,numAttacked)
                                break # Nothing else to do if a square has been found to be attacked.
                                
            screen.fill(self._fillColour)

            if not postHit:
                if network:
                    myNumber = 0
                    enemyNumber = 1
                else:
                    myNumber = playerNumbers[currentPlayer]
                    enemyNumber = playerNumbers[(currentPlayer+1+numAttacked) % numPlayers]
                myBoard = self._game.getBoard(myNumber)
                for x in range(len(squares)):
                    row = x // WidthInSquares
                    col = x % WidthInSquares
                    if myBoard[row][col] == 1:
                        pg.draw.rect(screen, (0,255,0), squares[x]) # Green fill for a ship.
                    elif myBoard[row][col] == 0:   # y coord is the % because of how I defined enemySquares.
                        pg.draw.rect(screen, (255,255,255), squares[x], 1) # White grid for an unknown
                    elif myBoard[row][col] == -1:
                        pg.draw.rect(screen, (255,0,0), squares[x]) # Red fill for a hit ship
                    else:
                        pg.draw.rect(screen, (0,0,255), squares[x]) # Blue fill for known empty
                
                enemySecretBoard = self._game.getSBoard(enemyNumber) # 0 = empty, -1 = hit ship, -2 = hit empty
                for x in range(len(enemySquares)):
                    row = x // WidthInSquares
                    col = x % WidthInSquares
                    if enemySecretBoard[row][col] >= 0:   # y coord is the % because of how I defined enemySquares.
                        pg.draw.rect(screen, (255,255,255), enemySquares[x], 1) # White grid for an unknown
                    elif enemySecretBoard[row][col] == -1:
                        pg.draw.rect(screen, (255,0,0), enemySquares[x]) # Red fill for a hit ship
                    else:
                        pg.draw.rect(screen, (0,0,255), enemySquares[x]) # Blue fill for known empty

                screen.blit(attackTypeImage, attackTypeRect) # Drawing the current attack type, N, B, or R
                screen.blit(numberImages[myNumber+1], (0,6*self._scale)) # Drawing the current player number
                screen.blit(numberImages[enemyNumber+1], (screen.get_width()-3*self._scale, screen.get_height()-5*self._scale)) # Drawing the other grid's player
            else:
                if isinstance(result, list):
                    if len(result) == 1:
                        screen.blit(numberImages[result[0]], (screen.get_width()//2, screen.get_height()//2))
                    else:
                        x,y = map(str, result)
                        count = 0
                        for ch in x:
                            ch = int(ch)
                            screen.blit(numberImages[ch], (count*self._scale*3, 0))
                            count += 1
                        
                        count += 1
                        for ch in y:
                            ch = int(ch)
                            screen.blit(numberImages[ch], (count*self._scale*3, 0))
                            count += 1
                pass
            pg.display.update()

        attacks = hits + misses
        if self._username != "":
            if result == [1]:
                self._network.send(f"updateStats {self._username} {1},{0},{hits},{misses},{self._game.getHP(0)},{attacks}")
            else:
                self._network.send(f"updateStats {self._username} {0},{1},{hits},{misses},{0},{10000000000000}")
        if network and result == [2]:
            self._network.send(f"deletegame {gameID}")
        elif game is not None:
            self._network.send(f"deletegame {game[1]}")

    def __addNewResolution(self, newScale):
        ogScale = 2
        scaleIncrease = newScale//ogScale
        print(newScale, scaleIncrease, ogScale)

        if not os.path.isdir(f"FinalImages\\Scale{ogScale*scaleIncrease}"): # Check if the folder already exists.
            # If the folder does not exist, we can create it.
            fileNames = os.listdir(f"FinalImages\\Scale{ogScale}")
            images = []
            for name in fileNames:
                images.append(Image.open(f"FinalImages\\Scale{ogScale}\\{name}"))

            os.mkdir(f"FinalImages\\Scale{int(ogScale*scaleIncrease)}")
            for x in range(len(images)):
                #resize
                n_size=(images[x].size[0]*scaleIncrease,images[x].size[1]*scaleIncrease) #output size
                res=images[x].resize(n_size,Image.Resampling.NEAREST)

                #save image
                res.save(f"FinalImages\\Scale{ogScale*scaleIncrease}\\{fileNames[x]}") # Scale is relative to 48 * 27 pixels
            
        self._scale = ogScale * scaleIncrease
        self._width = 48*self._scale
        self._height = 27*self._scale
        self._finalImagePath = f"FinalImages\\Scale{self._scale}\\"
        pg.quit()
        self.__mainMenu()

    def __help(self):
        # Initialise
        pg.init()
        screen = pg.display.set_mode((self._width, self._height))
        runningHelp = True

        # Buttons
        help = pg.image.load(f"{self._finalImagePath}HelpMenu.png")

        while runningHelp:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    runningHelp = False
                elif event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE:
                    runningHelp = False
            screen.blit(help, (0,0))
            pg.display.update()

    def __options(self):
        pg.init()
        screen = pg.display.set_mode((self._width, self._height))
        runningOptions = True
        titles = ["resolution", "length", "height", "ShipOne", "ShipTwo", "ShipThree", "ShipFour", "ShipFive", "ShipSix", "Barrage", "Radar", "Mine", "HitStreak", "numplayers"]
        changed = {}
        option = pg.image.load(f"{self._finalImagePath}OptionsMenu.png")
        result = ""

        while runningOptions:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    runningOptions = False
                if event.type == pg.KEYDOWN:
                    if event.key == pg.K_ESCAPE:
                        runningOptions = False
                    elif 48 <= event.key <= 57:
                        result += chr(event.key)
                    elif event.key == pg.K_RETURN:
                        try:
                            toChange = int(result)
                        except:
                            result = ""
                            break
                        result = ""
                        height = Game.getHeight()
                        width = Game.getWidth()
                        try:
                            if toChange != 13:
                                newNum = int(self.__getUserInput(titles[toChange-1]))
                        except Exception as e:
                            print(e, toChange)
                            break

                        if toChange == 1:
                            self.__addNewResolution(newNum)
                            runningOptions = False
                        elif toChange == 14:
                            if newNum > 1:
                                Game.changeNumPlayers(newNum)
                            else:
                                print("Must be 2 or more players")
                            changed[int(toChange)-1] = newNum 
                        elif toChange == 13:
                            pass
                        else:
                            changed[int(toChange)-2] = newNum

                        if toChange == 2:
                            Game.changeBoardDimensions(newNum, height)
                        elif toChange == 3:
                            Game.changeBoardDimensions(width, newNum)
                        elif 4 <= toChange <= 9:
                            Game.changeShips(toChange - 4, newNum)
                        elif 10 <= toChange <= 12:
                            Game.changeSpecials(toChange-10, newNum)
                        elif toChange == 13:
                            try:
                                red = int(self.__getUserInput("Red"))
                                blue = int(self.__getUserInput("Blue"))
                                green = int(self.__getUserInput("Green"))
                            except ValueError:
                                break
                            self._fillColour = (red, blue, green)

            screen.blit(option, (0,0))
            pg.display.update()

        self.updateOptions(changed)

    def __load(self):
        if self._username is not None:
            loads = self._network.send(f"getLoads {self._username}")
        else:
            return

        choice = "a"
        while not choice.isnumeric():
            print("".join(loads), loads)
            choice = self.__getUserInput("".join(loads)) # Get the game id the user wants to load
            if choice == "":
                return
        grids = self._network.send(f"loadGame {choice}")
        grid1, grid2, ai = grids.split(" ")
        ai = int(ai)
        Game.changeAI(ai)
        game = Game()

        for coordinate in grid1.split("|"): 
            x,y = coordinate.split(",")
            game.addShip(0, f"{x}{y}{0}{1}")

        for coordinate in grid2.split("|"):
            x,y = coordinate.split(",")
            game.addShip(1, f"{x}{y}{0}{1}")

        self.__local(False, ai, [game, False])

    def __save(self):
        if self._username is None:
            print("Must be logged in")
            return
        board1 = self._game.getBoard(0)
        grid1 = ""
        for y, row in enumerate(board1):
            for x, value in enumerate(row):
                if value == 1:
                    grid1 += f"{x},{y}|"
        grid1 = grid1[:-1]

        board2 = self._game.getBoard(1)
        grid2 = ""
        for y, row in enumerate(board2):
            for x, value in enumerate(row):
                if value == 1:
                    grid2 += f"{x},{y}|"
        grid2 = grid2[:-1]

        self._network.send(f'addGame {grid1} {grid2} {self._username} Guest ""')

    def __authenticate(self, authtype):
        pg.init()
        screen = pg.display.set_mode((self._width, self._height))
        runningAuthenticate = True
        # Buttons
        rects = [None, None]
        rects[0] = pg.Rect(16*self._scale, 11*self._scale, 19*self._scale, 6*self._scale)
        rects[1] = pg.Rect(17*self._scale, 19*self._scale, 17*self._scale, 6*self._scale)
        if authtype == "login":
            backGround = pg.image.load(f"{self._finalImagePath}LoginMenu.png")
        else:
            backGround = pg.image.load(f"{self._finalImagePath}SignUpMenu.png")

        password = ""
        while runningAuthenticate:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    runningAuthenticate = False
                elif event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE:
                    runningAuthenticate = False
                elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
                    mouseLocation = pg.mouse.get_pos()
                    for index, rect in enumerate(rects):
                        if rect.collidepoint(mouseLocation):
                            if index == 0:
                                self._username = self.__getUserInput("USERNAME")
                            else:
                                password = self.__getUserInput("PASSWORD")

                            if self._username != "" and password != "":
                                if authtype == "login":
                                    valid = self._network.send(f"login {self._username} {self.hash(password + self._username)}")
                                    if valid == "false":
                                        self._username =  ""
                                        password = ""
                                    else:
                                        runningAuthenticate = False
                                else:
                                    valid = self._network.send(f"signUp {self._username} {self.hash(password + self._username)}")
                                    if valid == "not_unique":
                                        self._username = ""
                                        password = ""
                                    else:
                                        runningAuthenticate = False

            screen.blit(backGround, (0,0))
            pg.display.update()

        if self._username != "":
            self.__playMenu()
        else:
            return

    def __getUserInput(self, title): # returns a string
        runningUserInput = True
        re = ""
        screen = pg.display.set_mode((self._width, self._height))

        underline = pg.image.load(f"{self._finalImagePath}Underline.png")
        titleLetters = []
        for letter in title:
            titleLetters.append(pg.image.load(f"{self._finalImagePath}{letter.upper()}.png"))

        letterImages = []
        delta = 0
        while runningUserInput:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    runningUserInput = False
                elif event.type == pg.KEYDOWN:
                    if event.key == pg.K_BACKSPACE:
                        re = re[:-1]
                        letterImages.pop()
                    elif event.key == pg.K_LSHIFT:
                        if delta == 0:
                            delta = -32
                        else:
                            delta = 0
                    elif event.key == pg.K_ESCAPE or event.key == pg.K_RETURN:
                        runningUserInput = False
                    elif event.key == pg.K_CAPSLOCK:
                        if delta == 0:
                            delta = -32
                        else:
                            delta = 0
                    else:
                        try: 
                            chr(event.key).isalpha()
                            re += chr(event.key+delta)
                            print(event.key+delta, delta, re)
                            letterImages.append(pg.image.load(f"{self._finalImagePath}{chr(event.key).upper()}.png"))
                        except ValueError:
                            pass
                elif event.type == pg.KEYUP:
                    if event.key == pg.K_LSHIFT:
                        if delta == 0:
                            delta = -32
                        else:
                            delta = 0

            screen.fill(self._fillColour)
            position = 0
            for index, letter in enumerate(titleLetters):
                if title[index].upper() == "M" or title[index].upper() == "W":
                    letterSize = 6
                elif title[index].upper() == "Q":
                    letterSize = 5
                elif title[index].upper() == "I":
                    letterSize = 2
                elif title[index].upper() == ",":
                    letterSize = 1
                else:
                    letterSize = 4
                if title[index].isupper():
                    screen.blit(underline, (position, round(7.5*self._scale)))
                screen.blit(letter, (position, self._scale))
                position += self._scale*letterSize

            position = 0
            for index, letter in enumerate(letterImages):
                if re[index].upper() == "M" or re[index].upper() == "W":
                    letterSize = 6
                elif re[index].upper() == "Q":
                    letterSize = 5
                elif re[index].upper() == "I":
                    letterSize = 2
                else:
                    letterSize = 4
                if re[index].isupper():
                    screen.blit(underline, (position, round(self._height//2 + 6*self._scale)))
                screen.blit(letter, (position, self._height//2))
                position += self._scale*letterSize
            pg.display.update()

        print("DEBUG -- Returning re", re)
        return re

#########################################################################
#
# CATEGORY A SKILL: Inheritance
# The Terminal inherits from the base UI class
#
#########################################################################
class Terminal(UI):
    def __init__(self):
        super().__init__()
        
    def run(self):
        self.__mainMenu()
    
    def __mainMenu(self):
        while True:
            print(text2art("Battleships"))
            print("Main Menu:")
            print("1. Log in")
            print("2. Sign up")
            print("3. Guest")
            print("4. Statistics")
            print("5. Quit")

            opt = input()
            if opt == "1":
                self.__logIn()
            elif opt == "2":
                self.__signUp()
            elif opt == "3":
                self.__playMenu()
            elif opt == "4":
                self.__stats()
            else:
                break

    def __signUp(self):
        valid = "not_unique"
        while valid == "not_unique":
            print("--The username must be unique--")
            self._username = input("Username - ")
            password = input("Password - ")
            if " " in self._username or " " in password:
                print("Username or password cannot have spaces!")
            else:
                valid = self._network.send(f"signUp {self._username} {self.hash(password + self._username)}")
            print("")
            
        self.__playMenu()

    def __logIn(self):
        valid = "false"
        while valid == "false":
            self._username = input("Username - ")
            password = input("Password - ")
            print("")
            start = time.perf_counter()
            valid = self._network.send(f"login {self._username} {self.hash(password + self._username)}")
        
        print(time.perf_counter() - start)
        self.__playMenu()

    def __stats(self):
        if self._username != "":
            stats = self._network.send(f"getStats {self._username}")
        print("Format: wins,losses,hits,misses,highestHP,leastAttacks")
        input(stats)

    def __playMenu(self):
        while True:
            print(text2art("Battleships"))
            print("1. Local")
            print("2. Network")
            print("3. AI Opponent")
            print("4. Help")
            print("5. Options")
            print("6. Load Game")
            print("7. Quit")
            opt = input()
            if opt == "1":
                self.__local(0) # No ai
            elif opt == "2":
                self.__networkGame()
            elif opt == "3":
                self.__local(input("What AI difficulty? 1,2 or 3"))
            elif opt == "4":
                self.__help()
            elif opt == "5":
                self.__options()
            elif opt == "6":
                self.__load()
            else:
                break
   
    def __getShipInput(self, playerNumber, ai, y): # x = player number, ai = ai difficulty, y = index of ship to be placed
        if int(ai) != 0:
            if playerNumber == 1:
                return self._game.getAIShip(y)
        return input((f"Ship in format x,y,r")).split(",")

    def __getAttackInput(self, playerNumber, ai): # x = player number, ai = ai difficulty
        if int(ai) != 0:
            if playerNumber == 1:
                return [self._game.getAIAttack(), 0]

        attackType = "a"
        specialCounts = self._game.getSpecialCount(playerNumber)[:2]
        while not attackType.isnumeric() or (attackType != "0" and specialCounts[int(attackType)-1] == 0):
            print("Your specials: [barrageCount, radarCount]")
            print(specialCounts) # Don't care about mines or hitstreak
            print("0 - normal, 1 - barrage, 2 - radar")
            attackType = input("What attack do you want to use?")
            print("")
        
        attackType = int(attackType)

        if attackType <= 1:
            coordinates = ["a"]
            while len(coordinates) < 2 or not coordinates[0].isnumeric() or not coordinates[1].isnumeric():
                coordinates = input("Input square to attack (x,y), can't attack the same square twice.").split(",")
            return coordinates, attackType
        return 0, attackType

    def __displayBoard(self, playerNum):
        for row in self._game.getBoard(playerNum):
            print(row)

    def __local(self,aiDifficulty, game=None): # aiDifficulty is 0,1,2 or 3, 0 for no ai, and then 1,2,3 for difficulty level.
        #########################################################################
        #
        # CATEGORY A SKILL: Composition
        # Storing a Game object as a characteristic of the Terminal class
        #
        #########################################################################
        if game is None:
            Game.changeAI(aiDifficulty)
            print("AI difficulty:", aiDifficulty)
            self._game = Game()
            numPlayers = Game.getNumPlayers()
        else:
            self._game = game[0]
            numPlayers = 2

        hints = []
        if Game.getSpecials()[4]:
            hints = [
                    ["Don't place ships to close to eachother.", "Be unpredictable", "Don't repeat what you have done previously.", "Place ships further from centre."], 
                    ["The centre is most likely to contain ships", "Attack around an already hit ship to finnish it off.", "Attack in diagonals."]
                    ]
        
        if self._username != "":
            attacks = 0
            hits = 0
            misses = 0

        if game is None:
            for playerNum in range(numPlayers): # Placing ships.
                print(f"Player {playerNum+1} turn")
                self.__displayBoard(playerNum)

                numShips = Game.getNumShips()
                ships = Game.getShips()

                for ship in ships:
                    if len(hints):
                        print(random.choice(hints[0]))
                    print(f"Player {playerNum+1} to place down ship of length {ship}")

                    shipLocation = self.__getShipInput(playerNum, aiDifficulty, numShips-1)
                    shipLocation.append(ship)
                    while self._game.addShip(playerNum, shipLocation) == -1:
                        print("Invalid ship position, current state of board:")
                        self.__displayBoard(playerNum)
                        shipLocation = self.__getShipInput(playerNum, 0, numShips-1)
                        shipLocation.append(ship)

                    numShips -= 1

                self.__displayBoard(playerNum)

                input("Press enter to change turns and clear terminal")
                os.system('cls')

            print("Time to attack!")
      
        print(numPlayers)
        playerNumbers = [num for num in range(numPlayers)]
        play = True
        while play:
            choice = input("Write 's' to save, anything else to continue")
            if choice.lower() == "s":
                if numPlayers != 2:
                    print("Can only save two player games.") 
                self.__save()
                break
            for playerNum in range(len(playerNumbers)):
                if not play:
                    break
                print(f"Player {playerNumbers[playerNum]+1} turn")
                print(f"Player {playerNumbers[playerNum]+1} board:")
                self.__displayBoard(playerNumbers[playerNum])

                if len(hints):
                    print(random.choice(hints[1]))
                for deltaPlayer in range(1, numPlayers):
                    toAttack = playerNumbers[(playerNumbers[playerNum]+deltaPlayer) % numPlayers]

                    print(f"Player {(toAttack) + 1} secret board:")
                    for row in self._game.getSBoard(toAttack): # it returns a 2d array, so we print the rows.
                        print(row)

                    result = -2
                    while result == -2: # Returing -2 = already hit square or error, -1 = miss, 1 = hit ship, 2 = game won
                        attackLocation, attackType = self.__getAttackInput(playerNumbers[playerNum], aiDifficulty)
                        result = -2
                        if attackType == 2:
                            result = self._game.radar(toAttack, playerNumbers[playerNum])
                            print(f"There is a ship at x={result[0]}, y={result[1]}")
                        else:
                            try:
                                result = self._game.attack(int(attackLocation[0]), int(attackLocation[1]), toAttack, attackType, playerNumbers[playerNum]) # Index starts at 0
                            except IndexError:
                                print("Invalid attack format")

                    if result == 2:
                        numPlayers -= 1
                        if numPlayers == 1:
                            print("Hit!")
                            print(f"Player {playerNumbers[playerNum]+1} wins!")
                            play = False
                            break
                        else:
                            print(toAttack+1, "was eliminated.")
                            playerNumbers.remove(toAttack)
                    elif result == 1:
                        print("Hit!")
                    elif result == -1:
                        print("Miss!")

                    if playerNumbers[playerNum] == 0 and aiDifficulty and self._username:
                        attacks += 1
                        if result == 2:
                            hits += 1
                            self._network.send(f"updateStats {self._username} {1},{0},{hits},{misses},{self._game.getHP(0)},{attacks}")
                        elif result == 1:
                            hits += 1
                        else:
                            misses += 1
                    elif result == 2 and aiDifficulty and self._username: # AI won
                        self._network.send(f"updateStats {self._username} {0},{1},{hits},{misses},{self._game.getHP(0)},{attacks}")

                input("Press enter to change turns and clear terminal")
                os.system('cls')

        if game is not None:
            self._network.send(f"deletegame {game[1]}")

    def __networkGame(self):
        #########################################################################
        #
        # CATEGORY A SKILL: Composition
        # Storing a Game object as a characteristic of the Terminal class
        #
        #########################################################################
        self._game = Game()
        if self._username == "":
            print("Must be logged in!")
            return
        print(text2art("Online"))
        enemyName = input("What is your enemy's username?")
        print("Setting up game with opponent...")
        playerNum, gameID = self._network.send(f"startGame {self._username} {enemyName}").split(" ")
        playerNum = int(playerNum[1]) - 1

        # get and compare player statistics
        hits = 0
        misses = 0

        try:
            myStats = list(map(int, self._network.send(f"getStats {self._username}").split(","))) # wins,losses,hits,misses,highestHP,leastAttacks
            enemyStats = list(map(int, self._network.send(f"getStats {enemyName}").split(",")))
            needsHelp = self.compareStats(myStats, enemyStats)
            print(myStats, enemyStats)
        except:
            needsHelp = -1

        if needsHelp != -1:
            print(f"It is recommended that player {needsHelp+1} gets help.")
            if needsHelp == playerNum:
                if input("Do you want to change your options to make the game easier? (Y/N)").upper() == "Y":
                    self.__options()
                else:
                    print("OK, continue as is. Good luck!")
            else:
                print("Checking if enemy player wants to get help.")

        self.__displayBoard(playerNum)
        numShips = Game.getNumShips()
        ships = Game.getShips()

        for ship in ships:
            print(f"Place down a ship of length {ship}")
            shipLocation = self.__getShipInput(playerNum, 0, numShips-1)
            shipLocation.append(ship)
            while self._game.addShip(playerNum, shipLocation) == -1:
                print("Invalid ship position, current state of board:")
                self.__displayBoard(playerNum)
                shipLocation = self.__getShipInput(playerNum, 0, numShips-1)
                shipLocation.append(ship)
            numShips -= 1

        board = self._game.getBoard(playerNum)
        grid = ""
        for y, row in enumerate(board):
            for x, value in enumerate(row):
                if value == 1:
                    grid += f"{x},{y}|"

        grid = grid[:-1]
        self._network.send(f"updateGrids {grid} {gameID} {playerNum}")
        enemyGrid = self._network.send(f"getGrid {gameID} {(playerNum+1)%2}").split("|")
        for coordinate in enemyGrid:
            x,y = coordinate.split(",")
            self._game.addShip((playerNum+1) % 2, f"{x}{y}11")
        # Ships have been placed
        # Start attacking:
        play = True
        while play:
            print("Your board:")
            self.__displayBoard(playerNum)
            print("")
            print("Enemy secret board")
            for row in self._game.getSBoard((playerNum+1)%2):
                print(row)
            result = -2
            while result == -2: # Returing -2 = already hit square or error, -1 = miss, 1 = hit ship, 2 = game won
                attackLocation, attackType = self.__getAttackInput(playerNum, 0)
                result = -2
                if attackType == 2:
                    result = self._game.radar((playerNum+1) % 2)
                    print(f"There is a ship at x={result[0]}, y={result[1]}")
                else:
                    try:
                        result = self._game.attack(int(attackLocation[0]), int(attackLocation[1]), (playerNum+1) % 2, attackType) # Index starts at 0
                    except IndexError:
                        print("Invalid attack format")
            if result == 2:
                hits += 1
                print("Hit!")
                print(f"Player {playerNum+1} wins!")
                play = False
                self._network.send(f"updateStats {1},{0},{hits},{misses},{0},{10000000}")
            elif result == 1:
                hits += 1
                print("Hit!")
            elif result == -1:
                misses += 1
                print("Miss!")
            
            previousAttack = self._network.send(f"updatePreviousAttack {attackLocation[0]} {attackLocation[1]} {playerNum} {attackType} {gameID}")
            print("Enemy player attacked - ", previousAttack)
            x, y, attackType, pnumignore = map(int, previousAttack.split(" "))
            result = self._game.attack(x, y, playerNum, attackType)
            if result == 2:
                self._network.send(f"updateStats {0},{1},{hits},{misses},{0},{10000000}")
                play = False

        self._network.send(f"deletegame, {gameID}")

    def __help(self):
        print("\n")
        print(text2art("RULES"))
        print("The game consists of consists of two phases, the preparation and attack phases.")
        print("In the preperation phase, players place own all of their ships on a grid (often 10x10).")
        print("---------------------------------------------------------------------------------------")
        print("In the attack phase, it is time to attack the other players' ships")
        print("Do this by choosing a square on the grid that you think contains an enemy ship")
        print("You will be told whether your attack was a hit, then it changes to another players turn")
        print("---------------------------------------------------------------------------------------")
        print("This cycle continues until one player has destroyed all of the enemies ships.")
        print("The last player with ships remaining wins!")
        input("Press any button to continue.")

    def __options(self):
        changed = {}
        while True:
            os.system('cls')
            ships = Game.getShips()
            width = Game.getWidth()
            height = Game.getHeight()
            numShips = [0,0,0,0,0,0]
            for ship in ships:
                numShips[ship-1] += 1
            specialsCounts = Game.getSpecials()
            numPlayers = Game.getNumPlayers()

            print("-----Options Menu-----")
            print(f"1. Grid Width {width}")
            print(f"2. Grid Height {height}")
            print(f"3. Ship One {numShips[0]}")
            print(f"4. Ship Two {numShips[1]}")
            print(f"5. Ship Three {numShips[2]}")
            print(f"6. Ship Four {numShips[3]}")
            print(f"7. Ship Five {numShips[4]}")
            print(f"8. Ship Six {numShips[5]}")

            print("-----Special Mode-----")
            print(f"9. Barrage {specialsCounts[0]}")
            print(f"10. Radar {specialsCounts[1]}")
            print(f"11. Mines {specialsCounts[2]}")
            print(f"12. Hit Streak {specialsCounts[3]}")
            print(f"13. Hints {specialsCounts[4]}")
            print(f"14. Number of players {numPlayers}")
            print("")
            print("Write the number of the thing you want to change, followed by what it should be changed to. (e.g. 11 -1)")
            print("Write 'E' to exit")
            inp = input()

            toChange = inp.split(" ")[0]
            if toChange == "E":
                break

            if len(inp.split(" ")) == 2:
                newNum = inp.split(" ")[1]
                try:
                    newNum = int(newNum)
                    toChange = int(toChange)
                except:
                    input("Invalid type")
                    continue
            
            #########################################################################
            #
            # CATEGORY B SKILL: Dictionaries
            # Adding a key value pair to a dictionary. This stores the option to be
            # changed, and what it should be changed to.
            #
            #########################################################################
            if toChange < 15:
                changed[toChange-1] = newNum
            else:
                continue
        
            if toChange == 1:
                Game.changeBoardDimensions(newNum, height)
            elif toChange == 2:
                Game.changeBoardDimensions(width, newNum)
            elif 3 <= toChange <= 8:
                Game.changeShips(int(toChange) - 3, newNum)
            elif 9 <= toChange <= 13:
                Game.changeSpecials(toChange-9, newNum)
            elif toChange == 14:
                if newNum > 1:
                    Game.changeNumPlayers(newNum)
                else:
                    print("Must be 2 or more players")
            Game.updatePlayers()
        
        self.updateOptions(changed)

    def __load(self):
        if self._username is not None:
            loads = self._network.send(f"getLoads {self._username}")
        for load in loads.split(","):
            print(load)

        choice = input("Which game would you like to load?")
        if choice.upper() == "E":
            return
        grids = self._network.send(f"loadGame {choice}")
        grid1, grid2, ai = grids.split(" ")

        Game.changeAI(ai)
        game = Game()

        for coordinate in grid1.split("|"): 
            x,y = coordinate.split(",")
            game.addShip(0, f"{x}{y}{0}{1}")

        for coordinate in grid2.split("|"):
            x,y = coordinate.split(",")
            game.addShip(1, f"{x}{y}{0}{1}")

        self.__local(ai, [game, int(choice)])

    def __save(self):
        if self._username is None:
            print("Must be logged in")
            return
        board1 = self._game.getBoard(0)
        grid1 = ""
        for y, row in enumerate(board1):
            for x, value in enumerate(row):
                if value == 1:
                    grid1 += f"{x},{y}|"
        grid1 = grid1[:-1]

        board2 = self._game.getBoard(1)
        grid2 = ""
        for y, row in enumerate(board2):
            for x, value in enumerate(row):
                if value == 1:
                    grid2 += f"{x},{y}|"
        grid2 = grid2[:-1]

        self._network.send(f'addGame {grid1} {grid2} {self._username} Guest ""')